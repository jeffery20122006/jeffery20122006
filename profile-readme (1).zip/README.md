<div align="center">

<img src="assets/banner.svg" alt="Hey there, I'm Jeffery Ebenezer Paul" width="100%"/>

</div>

<br/>

<div align="center">

## 🧰 Tech Stack

<img src="assets/techstack.svg" alt="Tech stack: Python, Java, C, HTML, CSS, JavaScript, React, Vite, Node.js, Express, MongoDB, MySQL, OpenCV, YOLO, Git, GitHub, VS Code, Postman" width="100%"/>

</div>

<br/>

<div align="center">

## 🚀 Featured Projects

<table>
  <tr>
    <td align="center">
      <a href="https://github.com/jeffery20122006?tab=repositories">
        <img src="assets/card-civicvision.svg" alt="CivicVision AI" width="100%"/>
      </a>
    </td>
    <td align="center">
      <a href="https://github.com/jeffery20122006?tab=repositories">
        <img src="assets/card-phishguard.svg" alt="PhishGuard" width="100%"/>
      </a>
    </td>
    <td align="center">
      <a href="https://github.com/jeffery20122006?tab=repositories">
        <img src="assets/card-interviewforge.svg" alt="InterviewForge" width="100%"/>
      </a>
    </td>
  </tr>
</table>

</div>

<br/>

<div align="center">

## 📊 GitHub Analytics

<img src="assets/stats.svg" alt="GitHub stats: commits, PRs, issues, languages, streak and contribution activity" width="100%"/>

</div>

<br/>

<div align="center">

## 🔗 Connect With Me

<a href="https://github.com/jeffery20122006"><img src="assets/btn-github.svg" alt="GitHub" height="64"/></a>
<a href="https://www.linkedin.com/in/YOUR-LINKEDIN-USERNAME"><img src="assets/btn-linkedin.svg" alt="LinkedIn" height="64"/></a>
<a href="https://www.linkedin.com/in/YOUR-LINKEDIN-USERNAME"><img src="assets/btn-email.svg" alt="Email" height="64"/></a>

<br/><br/>

<img src="assets/footer.svg" alt="Dream. Build. Innovate. Repeat." width="100%"/>

</div>
